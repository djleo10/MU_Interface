 function data = CKC_reader_Prakarsh_thumb(filepath,filename,epoch_length)
% function data = CKC_reader_Prakarsh_thumb(filepath,filename,epoch_length)
%
% CKC_reader: reads surface EMG acquired by a GR08MM1305 matrix 
% 
%
% INPUTS:
%   - filepath: directory with the SIG file to be loaded
%   - finename: EMG file to be loaded
%   - epoch_length: (optional) length of the epoch of signal to be loaded (in s)
%
% OUTPUT:
%   data: structure with the following fields;
%       SIG - two dimensional cell array with surface EMG channel in each
%             cell - SIG{r,c} is the channel in row r and column c. Missing
%             electrodes are denoted by empty arrays, e.g. SIG{1,1} = [];
%       fsamp - sampling frequency of sEMG
%       signal_length - length of a surface EMG signals (in samples)
%       montage - montage of electrodes - 'MONO' for monopolar, 'SD' for
%                 single differential
%       IED - inter-electrode distance (in mm)
%       ref_signal - measured reference signal (e.g. force) when avalable, empty array otherwise
%       AUXchannels - auxilary channels (currently not used by DEMUSEtool
%       description - text describing the data
%
% -----------------------------------------------------------------------
% Author: Ales Holobar (ales.holobar@um.si)
% Last modified: 9. 5. 2022

f=load([filepath filename]); 

data.SIG = {};
for r=1:size(f.grid_crds,1) % electrode array     
  data.SIG{f.grid_crds(r,1),f.grid_crds(r,2)} = f.out_mat(r,:);      
end

data.signal_length = length(f.out_mat);
data.ref_signal = f.stim;

clear SIG;

data.montage = 'MONO';
data.IED = 8.75;
data.fsamp = 4000;
data.AUXchannels = [];
data.description = ['SMA01'];