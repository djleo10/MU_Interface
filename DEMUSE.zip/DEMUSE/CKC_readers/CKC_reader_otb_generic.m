function data = CKC_reader_otb_generic(filepath,filename,epoch_length)
% CKC_reader: reads surface EMG from otb+ files - generic example
%

% INPUTS:
%   - filepath: directory with the SIG file to be loaded
%   - finename: EMG file to be loaded
%   - epoch_length: (optional) length of the epoch of signal to be loaded (in s)
%
% OUTPUT:
%   data: structure with the following fields;
%       SIG - two dimensional cell array with surface EMG channel in each
%             cell - SIG{r,c} is the channel in row r and column c. Missing
%             electrodes are denoted by empty arrays, e.g. SIG{1,1} = [];
%       fsamp - sampling frequency of sEMG
%       signal_length - length of a surface EMG signals (in samples)
%       montage - montage of electrodes - 'MONO' for monopolar, 'SD' for
%                 single differential
%       IED - inter-electrode distance (in mm)
%       ref_signal - measured reference signal (e.g. force) when avalable, empty array otherwise
%       AUXchannels - auxilary channels (currently not used by DEMUSEtool
%       description - text describing the data
%
% -----------------------------------------------------------------------

if ~exist('load_xml_otb','file')
    path(path,['.' filesep 'CKC_readers' filesep 'OTBioelletronica']);
    %path(path,['.' filesep 'CKC_readers' filesep 'OTBioelletronica' filesep 'xmltree' filesep ]);
end

currentDir = pwd;

if nargin < 3
    epoch_length = inf;
end
fsamp = 2048;

if (strcmp(filename(end-3:end),'.otb') || strcmp(filename(end-4:end),'.otb+'))
    %%%%%%%% OTB
    if ~exist([filepath 'renameTmp' filesep])
        mkdir([filepath 'renameTmp' filesep]);
    else
        %delete([filepath 'renameTmp' filesep '*.*']);
        try  rmdir([filepath 'renameTmp'],'s'); catch; end
    end
    copyfile([filepath filename],[filepath 'renameTmp' filesep filename]);
    cd([filepath 'renameTmp' filesep]);
    untar([filepath 'renameTmp' filesep filename]);
    signals=dir('*.sig');
    cd(currentDir);
    for nSig=1:1 %length(signals)
        PowerSupply{nSig}=5;
        tmp = dir([filepath 'renameTmp' filesep signals(nSig).name(1:6) '*.xml']);
        abstracts{nSig}=tmp.name;
        abs = xml2struct([filepath 'renameTmp' filesep abstracts{nSig}]);
        
        for nAtt=1:1
            try
                Fsample{nSig}=str2num(abs.Device.Attributes.SampleFrequency);
                nChannel{nSig}=str2num(abs.Device.Attributes.DeviceTotalChannels);
                nADBit{nSig}=str2num(abs.Device.Attributes.ad_bits);
                Gains{nSig} = str2num(abs.Device.Channels.Adapter{1}.Attributes.Gain);
            catch
                for nAtt=1:length(abs.Attributes)
                    if strcmp(abs.Attributes(nAtt).Name,'SampleFrequency')
                        Fsample{nSig}=str2num(abs.Attributes(nAtt).Value);
                    end
                    if strcmp(abs.Attributes(nAtt).Name,'Name')
                        if (strcmp(abs.Attributes(nAtt).Value,'EMG-USB'))
                            PowerSupply{nSig}=5;
                        end
                    end
                    if strcmp(abs.Attributes(nAtt).Name,'DeviceTotalChannels')
                        nChannel{nSig}=str2num(abs.Attributes(nAtt).Value);
                    end
                    if strcmp(abs.Attributes(nAtt).Name,'ad_bits')
                        nADBit{nSig}=str2num(abs.Attributes(nAtt).Value);
                    end
                end
                vett=zeros(1,nChannel{nSig});
                Gains{nSig}=vett;
                for nChild=1:length(abs.Children)
                    if strcmp(abs.Children(nChild).Name,'Channels')
                        Channels=abs.Children(nChild);
                        for nChild2=1:length(Channels.Children)
                            if strcmp(Channels.Children(nChild2).Name,'Adapter')
                                Adapter=Channels.Children(nChild2);
                                for nAtt2=1:length(Adapter.Attributes)
                                    if strcmp(Adapter.Attributes(nAtt2).Name,'Gain')
                                        localGain=str2num(Adapter.Attributes(nAtt2).Value);
                                    end
                                    if strcmp(Adapter.Attributes(nAtt2).Name,'ChannelStartIndex')
                                        startIndex=str2num(Adapter.Attributes(nAtt2).Value);
                                    end
                                end
                                for nChild3=1:length(Adapter.Children)
                                    if strcmp(Adapter.Children(nChild3).Name,'Channel')
                                        for nAtt3=1:length(Adapter.Children(nChild3).Attributes)
                                            if strcmp(Adapter.Children(nChild3).Attributes(nAtt3).Name,'Index')
                                                idx=str2num(Adapter.Children(nChild3).Attributes(nAtt3).Value);
                                                Gains{nSig}(startIndex+idx+1)=localGain;
                                            end
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
                
            end
        end
        h=fopen([filepath 'renameTmp' filesep signals(nSig).name],'r');
        data2=fread(h,[nChannel{nSig} epoch_length],'short');
        fclose(h);
        SIG=data2;
        try
            for nCh=1:nChannel{nSig}
                SIG(nCh,:)=SIG(nCh,:)*PowerSupply{nSig}/(2^nADBit{nSig})*1000000/Gains{nSig};
            end
        catch
            for nCh=1:nChannel{nSig}
                SIG(nCh,:)=SIG(nCh,:)*PowerSupply{nSig}/(2^nADBit{nSig})*1000000/Gains{nSig}(nCh);
            end
        end
    end
    try  rmdir([filepath 'renameTmp'],'s'); catch; end
    
    fsamp = Fsample{nSig};
end

% ElChannelMap = flipud([ ...  % ELSCH064NM3 matrix
%     1  2  3  4  5  6  7  8; ...
%     9  10 11 12 13 14 15 16; ...
%     17 18 19 20 21 22 23 24; ...
%     25 26 27 28 29 30 31 32; ...
%     33 34 35 36 37 38 39 40; ...
%     41 42 43 44 45 46 47 48; ...
%     49 50 51 52 53 54 55 56; ...
%     57 58 59 60 61 62 63 64;]);

% ElChannelMap = flipud(...
%      [ 0   1  2  3  4; ...  % ELSCH064NM2 matrix
%        16  8  7  6  5; ...
%        15 14 13 12 11; ...
%        19 18 17  9 10; ...
%        20 21 22 23 24; ...
%        28 29 30 31 32; ...
%        25 26 27 33 34; ...
%        35 36 37 38 39; ...
%        45 46 47 48 40; ...
%        44 43 42 41 49; ...
%        54 53 52 51 50; ...
%        55 56 64 63 62; ...
%        57 58 59 60 61]);
 
ElChannelMap = (...
    [ 0  25 26 51 52; ...  % GR08MM1305 matrix
    1  24 27 50 53; ...
    2  23 28 49 54; ...
    3  22 29 48 55; ...
    4  21 30 47 56; ...
    5  20 31 46 57; ...
    6  19 32 45 58; ...
    7  18 33 44 59; ...
    8  17 34 43 60; ...
    9  16 35 42 61; ...
    10 15 36 41 62; ...
    11 14 37 40 63; ...
    12 13 38 39 64]);

% ElChannelMap = flipud(...
%      [ 32 24 16 8; ...  % ELSCH064NM6 matrix
%        31 23 15 7; ...
%        30 22 14 6; ...
%        29 21 13 5; ...
%        28 20 12 4; ...
%        27 19 11 3; ...
%        26 18 10 2; ...
%        25 17 9  1]);

% ElChannelMap = flipud(...
%      [ 32  24 16 8; ...  % GR10MM0804 matrix
%        31  23 15 7; ...
%        30  22 14 6; ...
%        29  21 13 5; ...
%        28  20 12 4; ...
%        27  19 11 3; ...
%        26  18 10 2; ...
%        25  17 9  1 ]);

data.SIG = {};
for r=1:size(ElChannelMap,1) % electrode array
    for c=1:size(ElChannelMap,2)
        if ElChannelMap(r,c)>0
             data.SIG{r,c} = SIG(ElChannelMap(r,c),:);
        end
    end
end

data.signal_length = length(SIG);
data.ref_signal = SIG(65,:);  %% TODO: convert the force to N or Nm???
clear SIG;

data.montage = 'MONO';
data.IED = 8;
data.fsamp = fsamp;
data.AUXchannels = [];
data.description = ['muscle name'];

try  rmdir([filepath 'renameTmp'],'s'); catch; end

