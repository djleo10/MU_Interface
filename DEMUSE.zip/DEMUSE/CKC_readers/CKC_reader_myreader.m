function data = CKC_reader_myreader(filepath,filename,epoch_length)
% CKC_reader: reads surface EMG
%

% INPUTS:
%   - filepath: directory with the SIG file to be loaded
%   - finename: EMG file to be loaded
%   - epoch_length: (optional) length of the epoch of signal to be loaded (in s)
%
% OUTPUT:
%   data: structure with the following fields;
%       SIG - two dimensional cell array with surface EMG channel in each
%             cell - SIG{r,c} is the channel in row r and column c. Missing
%             electrodes are denoted by empty arrays, e.g. SIG{1,1} = [];
%       fsamp - sampling frequency of sEMG
%       signal_length - length of a surface EMG signals (in samples)
%       montage - montage of electrodes - 'MONO' for monopolar, 'SD' for
%                 single differential
%       IED - inter-electrode distance (in mm)
%       ref_signal - measured reference signal (e.g. force) when avalable, empty array otherwise
%       AUXchannels - auxilary channels (currently not used by DEMUSEtool)
%       description - text describing the data
%
% -----------------------------------------------------------------------

if nargin < 3
    epoch_length = inf;
end

NoChannels = 64; % set number of all the channels in the file with HDEMG signals (including AUX channels etc.)
h=fopen([filepath filesep filename],'r'); % get the file handle
SIG=fread(h,[nChannel{nSig} epoch_length],'short'); % read the channels. 
    
% determine the channal mapping that reflects the topology of HDEMG electrode array; index 0 denotes the missing electrode (if any)
ElChannelMap = flipud(...
     [ 0   1  2  3  4; ...  % This is ELSCH064NM2 electrode matrix from OT Bioelettronica, for example
       16  8  7  6  5; ...
       15 14 13 12 11; ...
       19 18 17  9 10; ...
       20 21 22 23 24; ...
       28 29 30 31 32; ...
       25 26 27 33 34; ...
       35 36 37 38 39; ...
       45 46 47 48 40; ...
       44 43 42 41 49; ...
       54 53 52 51 50; ...
       55 56 64 63 62; ...
       57 58 59 60 61]);

data.SIG = {}; 
for r=1:size(ElChannelMap,1) % map the channels into a 2D cell structure
    for c=1:size(ElChannelMap,2)
        if ElChannelMap(r,c)>0
             data.SIG{r,c} = SIG(ElChannelMap(r,c),:);
        end
    end
end

data.signal_length = length(SIG); %determine the signal length (in samples)
data.ref_signal(1,:) = SIG(65,:);  % read the force, trigger or any other reference signal
%data.ref_signal(2,:) = SIG(66,:);  % use this to add more reference signals when appropriate
clear SIG;

data.montage = 'MONO'; % acqusition mode: 'MONO' for monopolar, 'SD'  for single differential
data.IED = 8; % interelectrode distance
data.fsamp = 2048; % determine the sampling frequency ;
data.AUXchannels = []; % for AUX channals - currently not used by DEMUSEtool, leave it as currently defined. 
data.description = ['MM']; % specify here short signal description (e.g. muscle acronym)