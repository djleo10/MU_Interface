function x = hpbutter (x, cutoff_frequency,fsamp)
% INPUTS:
%   x - signal to be filtered
%   cutoff_frequency - cutoff frequency (in Hz)
%   fsamp - sampling frequency (in Hz)
% OUTPUTS:
%   x - filtered signal
if cutoff_frequency == 0;
    x=x;
elseif cutoff_frequency >= fsamp/2;
    x=0*x;
else
    [b,a] = butter(5,cutoff_frequency/fsamp*2,'high');
     x = filtfilt(b,a,double(x));
    %bhi = fir1(34,cutoff_frequency/fsamp*2,'high',chebwin(35,30));
    %x = filtfilt(bhi,1,double(x));
end

